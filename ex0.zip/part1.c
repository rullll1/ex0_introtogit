#include <stdlib.h>
#include <stdio.h>

int find_log(int n){
    int log = 0;
    while (n>1){
        n = n/2;
        log++;
    }
    return log;
}

int power(int a, int b){
    if (b == 0){
        return 1;
    }
    int answer = a;
    for (int i=1; i<b; i++){
        answer *= a;
    }
    return answer;
}


int main() {
    printf("Enter size of input:\n");
    int n;
    scanf("%d", &n);
    if (n < 1){
        printf("Invalid size\n");
        return 0;
    }
    int sum = 0;
    printf("Enter numbers:\n");
    int *arr = malloc(sizeof(int)* n);
    for (int i=0; i<n; i++){
        if (scanf("%d", &arr[i]) != 1){
            printf("Invalid number\n");
	    free(arr);
            return 0;
        }
    }
    for (int i=0; i<n; i++){
        int power_n= find_log(arr[i]);
        if (arr[i] == power(2,power_n)){
            printf("The number %d is a power of 2: %d = 2^%d\n", arr[i], arr[i], power_n);
            sum += power_n;
            }
    }
    printf("Total exponent sum is %d\n", sum);
    free(arr);

    return 0;
}
